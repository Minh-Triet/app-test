from dotenv import load_dotenv
from flask import Flask, jsonify, request
from flask_migrate import Migrate
from flask_restful import Api
import asyncio
from marshmallow import ValidationError
import nest_asyncio
from prometheus_flask_exporter import RESTfulPrometheusMetrics

from db import db
import ma

from resources.customer import Customer, CustomerList, CustomerDetail
from resources.trade import Trade, TradeList, TradeDetail
from resources.trade_cqg import TradeCQG
from datetime import datetime
from resources.cmsapi import CmsApi

app = Flask(__name__)
load_dotenv('.env', verbose=True)
app.config.from_object('development_config')  # load default configs from development_config.py
app.config.from_envvar('APPLICATION_SETTINGS')  # override with config.py (APPLICATION_SETTINGS points to config.py)

api = Api(app)
migrate = Migrate(app, db)
db.init_app(app)

loop = asyncio.new_event_loop()
asyncio.set_event_loop(asyncio.new_event_loop())
metrics = RESTfulPrometheusMetrics(app, api)

metrics.info("app_info", "App Info, this can be anything you want", version="1.0.0")


def job1():
    print(datetime.now())


nest_asyncio.apply()


@app.errorhandler(ValidationError)
def handle_marshmallow_validation(err):
    return jsonify(err.message), 400


api.add_resource(Trade, '/trades')
api.add_resource(TradeDetail, '/trade/<int:_id>')
api.add_resource(TradeList, '/trades')
api.add_resource(Customer, '/customer')
api.add_resource(CustomerDetail, '/customer/<int:_id>')
api.add_resource(CustomerList, '/customers')
api.add_resource(TradeCQG, '/')

api.add_resource(CmsApi, '/cmsapi')

if __name__ == '__main__':
    ma.ma.init_app(app)
    metrics.init_app(app)
    app.run(debug=True)
